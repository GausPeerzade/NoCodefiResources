# Lottery

## Description

A lottery for CAKE tokens built with Chainlink's VRF.