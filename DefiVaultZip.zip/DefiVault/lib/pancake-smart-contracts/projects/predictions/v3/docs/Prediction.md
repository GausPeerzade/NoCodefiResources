# Contract description

This document explains how the `Prediction` contract works.

