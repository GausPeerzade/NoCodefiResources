# IFO

## Description

This repo contains contracts for Initial Farm Offerings ("IFO").