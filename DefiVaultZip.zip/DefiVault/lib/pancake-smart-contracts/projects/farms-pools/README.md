# Pancake Farms and Pools

## Description

This repo includes various contracts like MasterChef (CAKE farms), SmartChef (single-asset pool), and the CAKE token contract.
