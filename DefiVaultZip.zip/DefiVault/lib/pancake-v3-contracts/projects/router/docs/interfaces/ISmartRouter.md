# Solidity API

## ISmartRouter

