# Solidity API

## PeripheryValidationExtended

### checkPreviousBlockhash

```solidity
modifier checkPreviousBlockhash(bytes32 previousBlockhash)
```

