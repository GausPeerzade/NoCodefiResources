# Solidity API

## IPancakeV3Pool

A PancakeSwap pool facilitates swapping and automated market making between any two assets that strictly conform
to the ERC20 specification

_The pool interface is broken up into many smaller pieces_

