# Solidity API

## ILMPoolDeployer

### deploy

```solidity
function deploy(contract IPancakeV3Pool pool) external returns (contract ILMPool lmPool)
```

