# Solidity API

## Multicall

Enables calling multiple methods in a single call to the contract

### multicall

```solidity
function multicall(bytes[] data) public payable returns (bytes[] results)
```

